document.addEventListener("DOMContentLoaded", () => {
    // Carousel Logic
    const carousel = document.querySelector('.carousel');
    const items = document.querySelectorAll('.carousel-item');
    const prevButton = document.querySelector('.carousel-btn.prev');
    const nextButton = document.querySelector('.carousel-btn.next');
    let currentIndex = 0;

    function updateCarousel() {
        const offset = -currentIndex * 100;
        if (carousel) carousel.style.transform = `translateX(${offset}%)`;
    }

    if (prevButton && nextButton) {
        prevButton.addEventListener('click', () => {
            currentIndex = (currentIndex === 0) ? items.length - 1 : currentIndex - 1;
            updateCarousel();
        });

        nextButton.addEventListener('click', () => {
            currentIndex = (currentIndex === items.length - 1) ? 0 : currentIndex + 1;
            updateCarousel();
        });
    }
    updateCarousel();

    // Gallery Lightbox
    document.querySelectorAll('.gallery-image').forEach(image => {
        image.addEventListener('click', () => {
            const lightbox = document.createElement('div');
            lightbox.classList.add('lightbox');
            lightbox.innerHTML = `
                <img src="${image.src}" alt="${image.alt}">
                <button class="close-lightbox" onclick="document.body.removeChild(this.parentElement)">X</button>
            `;
            document.body.appendChild(lightbox);
        });
    });

    // Blog Post Loader
    const blogData = {
        rila: {
            title: "Hiking in the Rila Mountains: A Complete Guide",
            image: "images/02-Rila-Mountains-Bulgaria.webp",
            content: `The Rila Mountains are one of Bulgaria's most treasured natural wonders. 
Known for their breathtaking beauty, they offer a variety of trails suitable for both novice and experienced hikers. 
The Seven Rila Lakes are undoubtedly the highlight, with their pristine waters reflecting the surrounding peaks.

Begin your hike early to make the most of your day. Wear sturdy hiking boots, and don’t forget to pack water, snacks, and warm clothing. 
During your journey, you’ll encounter rare flora and fauna, as well as spectacular views of valleys, forests, and ridges.

Other notable destinations in the Rila Mountains include the iconic Rila Monastery, a UNESCO World Heritage Site, and Mount Musala, the tallest peak in Bulgaria and the Balkans.

Whether you’re looking for a challenging adventure or a peaceful escape into nature, the Rila Mountains promise an unforgettable experience.
`,
            file: "downloads/rila.txt" 
        },
        plovdiv: {
            title: "Plovdiv: The Cultural Capital of Bulgaria",
            image: "images/1200px-Plovdiv_view.jpg",
            content: `Plovdiv, one of the oldest cities in the world, is a fascinating blend of history, art, and modern culture. 
The Old Town, with its cobblestone streets and well-preserved Revival-era houses, is a must-visit. 

Discover the Roman Theater, which continues to host performances, and Kapana, the creative district filled with trendy cafes and galleries.
History enthusiasts will love exploring Nebet Tepe, where ancient ruins meet stunning city views.

Food lovers should sample traditional Bulgarian dishes at one of Plovdiv’s many authentic restaurants. Don’t miss the chance to enjoy a glass of local wine from the nearby Thracian Valley, one of Europe’s top wine regions.

Whether you’re a history buff, an art lover, or a foodie, Plovdiv is a city that will leave you enchanted.
`,
            file: "downloads/plovdiv.txt" 
        },
        blacksea: {
            title: "The Black Sea Beaches: Top Destinations",
            image: "images/The-Black-Sea-Coast-Is-The-New-Mediterranean-Heres-Why-Its-So-Popular.jpg",
            content: `Bulgaria’s Black Sea coast offers something for everyone. From lively resorts like Sunny Beach to serene getaways like Albena, there’s no shortage of beautiful destinations to explore.

The beaches are known for their golden sands, warm waters, and vibrant nightlife. Golden Sands National Park, located near the resort, offers picturesque hiking trails and peaceful forests.

For a quieter experience, visit the historic town of Sozopol, known for its charming old houses and rich history. Another gem is Cape Kaliakra, where dramatic cliffs meet the azure sea.

The Black Sea coast isn’t just about the beaches. Explore seaside towns, indulge in fresh seafood, and enjoy the friendly local hospitality.
`,
            file: "downloads/blacksea.txt" 
        }
    };

    const params = new URLSearchParams(window.location.search);
    const postKey = params.get('post');
    const post = blogData[postKey];

    if (post) {
        document.getElementById('post-title').textContent = post.title;
        document.getElementById('post-image').src = post.image;
        document.getElementById('post-image').alt = post.title;
        document.getElementById('post-content').textContent = post.content;

        const downloadBtn = document.getElementById('download-btn');
        downloadBtn.href = post.file;
        downloadBtn.download = `${postKey}.txt`;
    }else{
        document.getElementById('post-title').textContent = "Post not found";
        document.getElementById('post-content').textContent = "The blog post you are looking for does not exist.";
    }
});

//comment section 
document.addEventListener("DOMContentLoaded", () => {
    const commentForm = document.getElementById("comment-form");
    const commentInput = document.getElementById("comment-input");
    const commentsList = document.getElementById("comments-list");

    // Load existing comments for the current blog post
    const params = new URLSearchParams(window.location.search);
    const postKey = params.get("post"); // e.g., "rila", "plovdiv", or "blacksea"
    let storedComments = JSON.parse(localStorage.getItem(`comments-${postKey}`)) || [];

    // Render comments on page load
    function renderComments() {
        commentsList.innerHTML = "";
        storedComments.forEach((comment, index) => {
            const commentDiv = document.createElement("div");
            commentDiv.classList.add("comment");

            const commentText = document.createElement("span");
            commentText.textContent = comment;

            const deleteBtn = document.createElement("button");
            deleteBtn.textContent = "Delete";
            deleteBtn.classList.add("delete-btn");

            // Add event listener to delete the comment
            deleteBtn.addEventListener("click", () => {
                storedComments.splice(index, 1); // Remove the comment from the array
                localStorage.setItem(`comments-${postKey}`, JSON.stringify(storedComments));
                renderComments(); // Re-render the comments
            });

            commentDiv.appendChild(commentText);
            commentDiv.appendChild(deleteBtn);
            commentsList.appendChild(commentDiv);
        });
    }

    renderComments();

    // Handle new comment submission
    commentForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const newComment = commentInput.value.trim();

        if (newComment) {
            storedComments.push(newComment);
            localStorage.setItem(`comments-${postKey}`, JSON.stringify(storedComments));
            commentInput.value = "";
            renderComments();
        }
    });
});
